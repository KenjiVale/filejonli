import { StyleSheet, Text, View, ImageBackground, PermissionsAndroid} from 'react-native'
import React, {useEffect, useState} from 'react'
import GetLocation from 'react-native-get-location';

import CityLocation from './CityLocation'
import ForecastPart from './ForecastPart'
import ForecastDetail from './ForecastDetail'

const API_KEY="91ec7fe6dce1da744e1e80951dcca7c5";
const img = require('../WeatherApp/src/assets/image/Background4.jpg')

const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

export default class App extends Component {
  state = {
    location: null,
    loading: false,
  };

  _requestLocation = (teste = '') => {
    this.setState({loading: true, location: null});

    GetLocation.getCurrentPosition({
      enableHighAccuracy: true,
      timeout: 150000,
    })
      .then(location => {
        this.setState({
          location,
          loading: false,
        });
      })
      .catch(ex => {
        const {code, message} = ex;
        console.warn(code, message);
        if (code === 'CANCELLED') {
          Alert.alert('Location cancelled by user or by another request');
        }
        if (code === 'UNAVAILABLE') {
          Alert.alert('Location service is disabled or unavailable');
        }
        if (code === 'TIMEOUT') {
          Alert.alert('Location request timed out');
        }
        if (code === 'UNAUTHORIZED') {
          Alert.alert('Authorization denied');
        }
        this.setState({
          location: null,
          loading: false,
        });
      });
  };

  render() {
    const {location, loading} = this.state;
    return (
      <View style={styles.container}>
      <ImageBackground source={img} style={styles.image}>
        <CityLocation/>
        <ForecastPart/>
        <ForecastDetail/>
      </ImageBackground>
      </View>
    );
  }
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
})

